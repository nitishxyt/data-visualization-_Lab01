import csv
f=open("example.csv",'a',newline='')
wo=csv.writer(f)

data=[['a','b','c'],[1,2,3,4,5,7,8]]
wo.writerow(data)
f.close()

f=open("example.csv",'r')
re=csv.reader(f)
li=list(re)
for row in li:
    print(row)
f.close()    