file = "python.txt"
search_key = input("Enter your search key word: ")

with open(file, "r") as file:
    for line in file:
        if search_key in line.lower():
            print(line)
print(f"Search for '{search_key}' Completed")