import pickle

file=open("binary.dat","wb")
li=[10,20,60,80,90]
pickle.dump(li,file)
file.close()

f=open("binary.dat","rb")
lin=pickle.load(f)
print(lin)
f.close
