# Write a program to count and display the lines starting with "T" in a text file story.txt
search_key = "india"
count = 0
with open("India.txt", "r") as file:
    for line in file:
        if search_key in line.lower():
            print(line.strip())
        if line.strip().startswith('T'):
            print(line.strip())
            count += 1
print(f"Search for '{search_key}' Completed")
print(f"Lines starting with 'T': {count}")