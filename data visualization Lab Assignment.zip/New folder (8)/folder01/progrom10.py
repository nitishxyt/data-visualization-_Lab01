# Write a program to read a binary file "Stu dat" and display the record of students having marks greater than 81

import struct

# Define the format string for struct packing/unpacking
record_format = '20sii'
record_size = struct.calcsize(record_format)

# Read and display the records of students having marks greater than 81
with open('binary.dat', 'rb') as file:
    while True:
        record = file.read(record_size)
        if not record:
            break
        name, age, marks = struct.unpack(record_format, record)
        name = name.decode('utf-8').strip('\x00')
        if marks > 81:
            print(f'Name: {name}, Age: {age}, Marks: {marks}')
