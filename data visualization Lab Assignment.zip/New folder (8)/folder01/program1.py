# Read and Display File Content Line by Line
def read_and_display_file(file_name):
    with open(file_name, 'r') as file:
        for line in file:
            print(line, end='')

# Usage
read_and_display_file("ABC.txt")




