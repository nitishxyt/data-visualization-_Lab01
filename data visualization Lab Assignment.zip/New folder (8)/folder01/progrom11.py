
# Write a program to create a binary fine "Stu dat" and Enter students rollno. Name and Marks till the user wants.

import struct

# Define the record format: 4 bytes for integer, 30 bytes for string
record_format = 'I30s'
record_size = struct.calcsize(record_format)

# Open the binary file
with open('stu.dat', 'rb') as file:
    while True:
        # Read a record from the file
        record = file.read(record_size)
        if not record:
            break
        
        # Unpack the record
        student_number, name = struct.unpack(record_format, record)
        name = name.decode('utf-8').strip()  # Decode and strip trailing null bytes
        
        # Check if the student number is greater than 81
        if student_number > 81:
            print(f"Student Number: {student_number}, Name: {name}")
