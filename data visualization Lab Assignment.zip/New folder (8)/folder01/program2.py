# Count and Display Total Number of Words
def count_words(file_name):
    with open(file_name, 'r') as file:
        content = file.read()
        words = content.split()
        word_count = len(words)
        print(f"Total number of words: {word_count}")

# Usage
count_words("ABC.txt")
