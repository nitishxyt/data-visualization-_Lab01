# Write a program to count the occurrence of word "INDIA" in a text file India txt
search_key = "india"    
with open("India.txt", "r") as file:
        # Iterate over each line in the file
        for line in file:
            # Check if the search key is in the line (case-insensitive)
            if search_key in line.lower():
                # Print the entire line if the search key is found
                print(line)
print(f"Search for '{search_key}' Completed")
     