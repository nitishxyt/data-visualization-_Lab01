# Write a program to count the number of vowels and Consonants in a file "Myfile.txt"
vowel_count = 0
consonant_count = 0

# Open the file
file = open("India.txt", "r")

# Process each line in the file
for line in file:
    line_lower = line.lower()
    
    # Count vowels and consonants
    for char in line_lower:
        if char.isalpha():
            if char in 'aeiou':
                vowel_count += 1
            else:
                consonant_count += 1

# Close the file
file.close()

print(f"Vowels: {vowel_count}, Consonants: {consonant_count}")
