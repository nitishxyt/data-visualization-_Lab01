# Write a program to count and display number of words starting with "i" in a file India.txt
word_start_i_count = 0

# Open the file
file = open("India.txt", "r")

# Process each line in the file
for line in file:
    line_lower = line.lower()
    
    # Split the line into words and count words starting with 'i'
    words = line_lower.split()
    for word in words:
        if word.startswith('i'):
            word_start_i_count += 1

file.close()

print("Words starting with 'i': ", word_start_i_count)
