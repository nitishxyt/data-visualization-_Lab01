
# Write a program to display the lines having more than five words in a text file Notes txt
# Open the file
file = open("India.txt", "r")

# Process each line in the file
for line in file:
    words = line.split()
    
    # Display lines with more than 5 words
    if len(words) > 5:
        print(line.strip())
# Close the file
file.close()


