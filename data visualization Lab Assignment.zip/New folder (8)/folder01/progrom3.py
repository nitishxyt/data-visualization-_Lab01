# Count Uppercase Characters
def count_uppercase_characters(file_name):
    with open(file_name, 'r') as file:
        content = file.read()
        uppercase_count = sum(1 for char in content if char.isupper())
        print(f"Total number of uppercase characters: {uppercase_count}")

# Usage
count_uppercase_characters("ABC.txt")
