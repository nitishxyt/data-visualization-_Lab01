# Display Words Less Than 4 Characters
def display_words(file_name):
    with open(file_name, 'r') as file:
        for line in file:
            words = line.split()
            for word in words:
                if len(word) < 4:
                    print(word)

# Usage
display_words("story.txt")
