# python progrom that prompts the user to user to input two number and raises a TypeError exception if input are not numarical
try:
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
except ValueError:
    raise TypeError("Input must be numerical")