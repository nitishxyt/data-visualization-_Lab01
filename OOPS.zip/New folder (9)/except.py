print("Line 1")
print("Line 2")
print("Line 3")
try:
  #print(100/0)
  open("abc.txt")

except ZeroDivisionError as e:
  print("Error: ", e)
except FileNotFoundError:
  print("File not found")
print("Line 4")
print("Line 5")
print("Line 6")
