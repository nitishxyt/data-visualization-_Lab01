class A:
    name="Nitish"
    def show(self):
        print("this is a class")
class B(A):
    pass


obj=B()
print(obj.name)
obj.show()


#  Multilavel  inharitances
class A:
    name="Nitish"
    def show(self):
        print("this is A class")
class B(A):
     def show(self):
        print("this is B  class")

class C(B):
     pass


obj=C()
print(obj.name)
obj.show()

# Hararical inharitances  
class A:
    name="Nitish"
    def show(self):
        print("this is A class")
class B(A):
     def show(self):
        print("this is B  class")

class C(A):
     pass
obj=C()
print(obj.name)
obj.show()


#maltipal in haritance   
class A:
    name="Nitish"
    def show(self):
        print("this is A class")
class B:
     def show(self):
        print("this is B  class")

class C(A,B):
     pass
obj=C()
print(obj.name)
obj.show()

# Hybreid inharitance
class A:
    name="Nitish"
    def shows(self):
        print("this is A class")
class B(A):
     def show(self):
        print("this is B  class")

class C(A):
     pass
class D(B,C):
    pass
obj=D()
print(obj.name)
obj.shows()
obj.show()