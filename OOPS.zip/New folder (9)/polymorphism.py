# def Data(name,age):
#     print(name)
#     print(age)
# def Data(name, age,roll): 
#       print(name)
#       print(age)
#       print(roll)

# Data("nitish",20)     
# Data("nitish",21,2000)


# polymorphism overriding

class Parent:
     def House(self):
          print("house of parent")

class Child(Parent):
     def House(self):
          print("house of child")

obj=Child()
obj.House()




# new example

class Bird:
     def intro(self):
          print("there are many types of birds")
     def  Flight(self):
          print("most of the birds can fly")
class sparrow(Bird):
     def Flight(self):
          print("i can fly")          
class ostrich(Bird):
     pass
s=sparrow()
s.Flight()


 


