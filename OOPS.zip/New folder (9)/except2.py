# progrom that prompts the user to input an program that prompts the user to input an integer and raises a ValueError exception if not valid
while True:
    try:
        user_input = int(input("Please enter an integer: "))
        break
    except ValueError:
        print("Invalid input. Please enter a valid integer.")