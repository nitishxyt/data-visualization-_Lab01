def show():
    print("Out side of class")

class student:
    def study(self):
        show()
        self.show()
        print("class")
    def show(self):
        print("inside of class")

# student().study()
odj=student()  
odj.study()          