def checkage(age):
    if (age>18):
        print("You are eligible to vote")   
    else:
        raise ValueError("You are not eligible to vote")  

try:
    checkage(100 or 2)
except ValueError as e:
    print("Error: ",e)
         