import numpy as np
a=np.array(45)
b=np.array([23,67,89])
c=np.array([[1,2,3,4],[6,7,8,9]])
print(a)
print(b)
print(c)



arr=np.array([True,False,True],dtype=np.bool)
print(arr)

#Generic python object type 
arr=np.array([1,2,3,4,5],dtype=object)
print(arr)

#String type for fixed lengh ASCII atring 
arr =np.array(["Hello","World"],dtype=np.string_)
print(arr)
