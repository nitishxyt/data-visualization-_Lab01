print("Line 1")
print("Line 2")
print("Line 3")
try:
  open("abc.txt")
  print(100/0)

except (ZeroDivisionError 
  ,FileNotFoundError):
   print("File not found")
print("Line 4")
print("Line 5")
print("Line 6")
# handling any type of except when

print("Line 1")
print("Line 2")
print("Line 3")
try:
  open("abc.txt")
  print(100/0)


except :
   print("File not found")
else:
   print("It is else")
finally:
   print("It is finally")
print("Line 4")
print("Line 5")
print("Line 6")